PHONE / TABLET (chat only)
==========================
1. Open https://noeticompute.com/mobile/
2. Add to Home Screen
Earn/compute needs the desktop zip for your OS (macOS / Windows / Linux).
