#!/bin/bash
cd "$(dirname "$0")"
HUB="${NOETIS_HUB:-https://noeticompute.com}"
export NOETIS_BIN_DIR="$(pwd)/bin"
export PATH="$NOETIS_BIN_DIR:$PATH"
# Clear Gatekeeper quarantine so compute stays alive & registers on the hub
xattr -cr . 2>/dev/null || true
echo ""
echo "  Starting Noetis…"
echo "  Browser opens → pick Chat or Earn."
echo "  Tip: keep this folder; use Check for updates later."
echo ""
# Run the binary directly (Do NOT open .app from Downloads — causes App Translocation)
exec ./bin/noetis-app --hub "$HUB"
