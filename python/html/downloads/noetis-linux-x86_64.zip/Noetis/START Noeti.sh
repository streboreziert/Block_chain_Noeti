#!/bin/bash
cd "$(dirname "$0")"
HUB="${NOETIS_HUB:-https://noeticompute.com}"
export NOETIS_BIN_DIR="$(pwd)/bin"
export NOETIS_CLIENT_DIR="$(pwd)/client"
export PATH="$NOETIS_BIN_DIR:$PATH"
# Apply staged binary update (written while previous noetis-app was running)
if [ -d bin/.pending ]; then
  for f in bin/.pending/*; do
    [ -f "$f" ] || continue
    mv -f "$f" "bin/$(basename "$f")"
    chmod +x "bin/$(basename "$f")" 2>/dev/null || true
  done
  rmdir bin/.pending 2>/dev/null || rm -rf bin/.pending
fi
chmod +x bin/noetis-* 2>/dev/null || true
echo ""
echo "  Starting Noeti (Linux)…"
echo "  Browser opens → pick Chat or Earn."
echo ""
exec ./bin/noetis-app --hub "$HUB"
