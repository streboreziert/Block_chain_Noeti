NOETI FOR LINUX — one click
============================
App version: 0.5.35

1. chmod +x "START Noeti.sh" bin/*
2. Run:  ./START\ Noeti.sh
   Or double-click START Noeti.sh / noetis.desktop

3. Browser opens → pick Chat or Earn

Need unzip for updates:  sudo apt install unzip   (or use tar.gz)

Phone chat: https://noeticompute.com/mobile/
